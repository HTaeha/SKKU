package edu.skku.todolist;

public class ListViewItem {
    private String name;
    private String dead_line;
    private String description;
    public ListViewItem(){
    }
    public ListViewItem(String str1, String str2, String str3){
        name = str1;
        dead_line = str2;
        description = str3;
    }
    public String getName(){
        return name;
    }
    public String getDead_line(){
        return dead_line;
    }
    public String getDescription(){
        return description;
    }
    public void setName(String str){
        name = str;
    }
    public void setDead_line(String str){
        dead_line = str;
    }
    public void setDescription(String str){
        description = str;
    }
}
