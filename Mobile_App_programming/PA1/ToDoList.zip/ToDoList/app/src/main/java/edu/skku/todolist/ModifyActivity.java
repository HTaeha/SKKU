package edu.skku.todolist;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

public class ModifyActivity extends AppCompatActivity {
    private ArrayList<String> result = new ArrayList<String>();
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.modify_item);

        final Intent intentResult = new Intent(this.getIntent());
        ArrayList<String> arrayList;
        arrayList = (ArrayList<String>) intentResult.getSerializableExtra("data");
        final String position = arrayList.get(0);

        final EditText editTextName = (EditText) findViewById(R.id.name);
        final EditText editTextDead = (EditText) findViewById(R.id.dead_line);
        final EditText editTextDesc = (EditText) findViewById(R.id.description);
        Button buttonApply = (Button) findViewById(R.id.applyButton);
        ImageView delete = (ImageView)findViewById(R.id.delete);

        Log.d("name", arrayList.get(1));
        Log.d("dead",arrayList.get(2));
        Log.d("desc",arrayList.get(3));
        editTextName.setText(arrayList.get(1));
        editTextDead.setText(arrayList.get(2));
        editTextDesc.setText(arrayList.get(3));

        buttonApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editTextName.getText().toString().equals("")){
                    Toast.makeText(ModifyActivity.this, "Please input Job name.", Toast.LENGTH_LONG).show();
                }else {
                    result.add(position);
                    result.add(editTextName.getText().toString());
                    result.add(editTextDead.getText().toString());
                    result.add(editTextDesc.getText().toString());
                    intentResult.putExtra("result", result);
                    setResult(RESULT_OK, intentResult);
                    finish();
                }
            }
        });
        delete.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                result.add(position);
                intentResult.putExtra("result", result);
                setResult(RESULT_CANCELED, intentResult);
                finish();
            }
        });
    }
}
