package edu.skku.todolist;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.*;
import android.widget.*;

public class MainActivity extends AppCompatActivity {
    EditText et_id,et_passwd;
    Button bt_login;
    String temp_id = "SKKU";
    String temp_password = "software";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        et_id = (EditText)findViewById(R.id.ID);
        et_passwd = (EditText)findViewById(R.id.password);
        bt_login = (Button)findViewById(R.id.loginButton);

        bt_login.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                String id = et_id.getText().toString();
                String passwd = et_passwd.getText().toString();
                boolean check = loginCheck(id, passwd);

                Log.d("click",et_id.getText().toString());
                if(check){
                    Toast.makeText(MainActivity.this, "Login Success", Toast.LENGTH_LONG).show();

                    Intent i=new Intent(MainActivity.this,SubActivity.class);
                    i.putExtra("text",String.valueOf(et_id.getText()));
                    startActivity(i);
                }else{
                    Toast.makeText(MainActivity.this, "Login Failed", Toast.LENGTH_LONG).show();
                }
            }
        });

    }
    private boolean loginCheck(String id, String password){
        if(id.equals(temp_id) && password.equals(temp_password)){
            return true;
        }else{
            return false;
        }
    }

}
