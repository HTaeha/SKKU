package edu.skku.todolist;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;

public class SubActivity extends AppCompatActivity {
    ListViewAdapter adapter1 = new ListViewAdapter();
    ListViewAdapter adapter2 = new ListViewAdapter();
    ListViewAdapter adapter3 = new ListViewAdapter();

    Button button1, button2, button3;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_sub);

        Intent intent = new Intent(this.getIntent());
        final String s = intent.getStringExtra("text");
        String welcome = "Welcome, ";
        String res = welcome + s;
        TextView textView = (TextView) findViewById(R.id.welcome);
        textView.setText(res);

        final Intent i_modify=new Intent(SubActivity.this,ModifyActivity.class);
        final ArrayList<String> sendModifyData = new ArrayList<String>();
        final ListViewItem[] item = {new ListViewItem()};

        final ListView listview1 = (ListView) findViewById(R.id.listview1);
        listview1.setAdapter(adapter1);
        listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                sendModifyData.clear();
                sendModifyData.add(String.valueOf(position));
                item[0] = (ListViewItem) adapter1.getItem(position);
                sendModifyData.add(item[0].getName());
                sendModifyData.add(item[0].getDead_line());
                sendModifyData.add(item[0].getDescription());
                i_modify.putExtra("data", sendModifyData);
                startActivityForResult(i_modify,100);
            }
        });
        ListView listview2 = (ListView) findViewById(R.id.listview2);
        listview2.setAdapter(adapter2);

        listview2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                sendModifyData.clear();
                sendModifyData.add(String.valueOf(position));
                item[0] = (ListViewItem) adapter2.getItem(position);
                sendModifyData.add(item[0].getName());
                sendModifyData.add(item[0].getDead_line());
                sendModifyData.add(item[0].getDescription());
                i_modify.putExtra("data", sendModifyData);
                startActivityForResult(i_modify,200);
            }
        });
        ListView listview3 = (ListView) findViewById(R.id.listview3);
        listview3.setAdapter(adapter3);

        listview3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                sendModifyData.clear();
                sendModifyData.add(String.valueOf(position));
                item[0] = (ListViewItem) adapter3.getItem(position);
                sendModifyData.add(item[0].getName());
                sendModifyData.add(item[0].getDead_line());
                sendModifyData.add(item[0].getDescription());
                i_modify.putExtra("data", sendModifyData);
                startActivityForResult(i_modify,300);
            }
        });
        button1 = (Button) findViewById(R.id.button1);
        button2 = (Button) findViewById(R.id.button2);
        button3 = (Button) findViewById(R.id.button3);

    }
    public void onClick(View v){
        Intent i_add=new Intent(SubActivity.this,AddActivity.class);
        switch(v.getId()){
            case R.id.button1:
                startActivityForResult(i_add,1000);
                break;
            case R.id.button2:
                startActivityForResult(i_add,2000);
                break;
            case R.id.button3:
                startActivityForResult(i_add,3000);
                break;
        }
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList = (ArrayList<String>) data.getSerializableExtra("result");
        ListViewItem item = new ListViewItem();

        if(resultCode == RESULT_OK){
            switch(requestCode){
                case 100:
                    item.setName(arrayList.get(1));
                    item.setDead_line(arrayList.get(2));
                    item.setDescription(arrayList.get(3));
                    adapter1.setItem(Integer.parseInt(arrayList.get(0)),item);
                    adapter1.notifyDataSetChanged();
                    break;
                case 200:
                    item.setName(arrayList.get(1));
                    item.setDead_line(arrayList.get(2));
                    item.setDescription(arrayList.get(3));
                    adapter2.setItem(Integer.parseInt(arrayList.get(0)),item);
                    adapter2.notifyDataSetChanged();
                    break;
                case 300:
                    item.setName(arrayList.get(1));
                    item.setDead_line(arrayList.get(2));
                    item.setDescription(arrayList.get(3));
                    adapter3.setItem(Integer.parseInt(arrayList.get(0)),item);
                    adapter3.notifyDataSetChanged();
                    break;
                case 1000:
                    adapter1.addItem(arrayList.get(0), arrayList.get(1), arrayList.get(2));
                    adapter1.notifyDataSetChanged();
                    break;
                case 2000:
                    adapter2.addItem(arrayList.get(0), arrayList.get(1), arrayList.get(2));
                    adapter2.notifyDataSetChanged();
                    break;
                case 3000:
                    adapter3.addItem(arrayList.get(0), arrayList.get(1), arrayList.get(2));
                    adapter3.notifyDataSetChanged();
                    break;
            }
        }else if(resultCode == RESULT_CANCELED){
            switch(requestCode){
                case 100:
                    adapter1.removeItem(Integer.parseInt(arrayList.get(0)));
                    adapter1.notifyDataSetChanged();
                    break;
                case 200:
                    adapter2.removeItem(Integer.parseInt(arrayList.get(0)));
                    adapter2.notifyDataSetChanged();
                    break;
                case 300:
                    adapter3.removeItem(Integer.parseInt(arrayList.get(0)));
                    adapter3.notifyDataSetChanged();
                    break;
            }
        }
    }
}