package edu.skku.todolist;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class AddActivity extends AppCompatActivity {
    private ArrayList<String> result = new ArrayList<String>();
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_item);

        final Intent intentResult = new Intent(this.getIntent());

        final EditText editTextName = (EditText) findViewById(R.id.name);
        final EditText editTextDead = (EditText) findViewById(R.id.dead_line);
        final EditText editTextDesc = (EditText) findViewById(R.id.description);
        Button buttonApply = (Button) findViewById(R.id.applyButton);

        buttonApply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(editTextName.getText().toString().equals("")){
                    Toast.makeText(AddActivity.this, "Please input Job name.", Toast.LENGTH_LONG).show();
                }else {
                    result.add(editTextName.getText().toString());
                    result.add(editTextDead.getText().toString());
                    result.add(editTextDesc.getText().toString());
                    intentResult.putExtra("result", result);
                    setResult(RESULT_OK, intentResult);
                    finish();
                }
            }
        });
    }
}
