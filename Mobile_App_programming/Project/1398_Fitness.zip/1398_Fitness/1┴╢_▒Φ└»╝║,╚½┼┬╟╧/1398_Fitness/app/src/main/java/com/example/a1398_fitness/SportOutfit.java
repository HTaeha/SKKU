package com.example.a1398_fitness;

import android.util.Log;

import java.io.Serializable;
import java.util.ArrayList;

public class SportOutfit implements Serializable {
    int id;
    int count;
    int set;
    int priority;

    public SportOutfit(int id , int set,int count, int prior){
        this.id = id;
        this.count = count;
        this.set = set;
        this.priority = prior;
    }
    public int getId() {
        return id;
    }
    public int getCount() {
        return count;
    }
    public int getSet() {
        return set;
    }
    public int getPriority() {
        return priority;
    }
    public void setId(int id) {
        this.id = id;
    }
    public void setCount(int count) {
        this.count = count;
    }
    public void setSet(int set) {
        this.set = set;
    }
    public void setPriority(int prior) {
        this.priority = prior;
    }
}
