package com.example.a1398_fitness;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MyPage extends AppCompatActivity {
    Button finish, cancel, back, out;
    TextView cnt1, set1, nowName;
    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference databaseReference = firebaseDatabase.getReference();

    User currentUser;

    int[] numOfOutfit = new int[11];
    int[] available = new int[11];
    int numOfUser;
    ArrayList<SportOutfit> myOutfit = new ArrayList<>();
    ListViewAdapter adapter = new ListViewAdapter();

    public static final int MYPAGERESERVATION_ID = 300;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_page);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        getNumOfOutfit();
        getAvailable();
//////////////////////////////////////////////////////////////어떤 운동(id)를 몇번씩(count) 몇세트(set)할지
        final Intent i = new Intent(this.getIntent());

        currentUser = (User)i.getSerializableExtra("user");
        myOutfit = (ArrayList<SportOutfit>)i.getSerializableExtra("outfit");

        ListView listview = (ListView) findViewById(R.id.listview);
        listview.setAdapter(adapter);

        finish = (Button) findViewById(R.id.finish);
        cancel = (Button) findViewById(R.id.cancel);
        back = (Button) findViewById(R.id.back);
        out = (Button) findViewById(R.id.out);
        nowName = (TextView) findViewById(R.id.nowName);
        cnt1 = (TextView) findViewById(R.id.count);
        set1 = (TextView) findViewById(R.id.set);

        if(currentUser.getNow().getId() != 0){
            String nName = getOutfitName(currentUser.getNow().getId());
            cnt1.setText(Integer.toString(currentUser.getNow().getCount())+cnt1.getText().toString());
            set1.setText(Integer.toString(currentUser.getNow().getSet())+set1.getText().toString());
            nowName.setText(nName);
        }
        for(int index=0;index<currentUser.getReservationSize();index++){
            adapter.addItem(currentUser.getReservation().get(index).getId(),getOutfitName(currentUser.getReservation().get(index).getId()),String.valueOf(currentUser.getReservation().get(index).getSet()),String.valueOf(currentUser.getReservation().get(index).getCount()));
            adapter.notifyDataSetChanged();
        }

        //////////////////////////////////////예약취소 버튼, 예약된 기구가 있으면 그 기구를 누르면 취소할 수 있는 화면으로 이동.
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                final Intent intent=new Intent(MyPage.this,MyPageReservation.class);
                ListViewItem temp = (ListViewItem)adapter.getItem(position);
                intent.putExtra("id", temp.getId());
                intent.putExtra("nowName", temp.getNowName());
                intent.putExtra("set", temp.getSet());
                intent.putExtra("count", temp.getCount());
                startActivityForResult(intent,MYPAGERESERVATION_ID);
            }
        });
        ///////////////////////////////돌아가기 버튼(메인화면으로)
        back.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                i.putExtra("user", currentUser);
                i.putExtra("outfit", myOutfit);
                setResult(RESULT_OK, i);
                finish();
            }
        });
        //////////////////////////////기구사용완료 버튼, users에 현재 사용중인 기구의 이용자 수가 담겨있으므로 1을 줄여서 DB에 저장
        finish.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                int removeID;
                removeID = currentUser.getNow().getId();
                removeSportOutfit(removeID);
                setAvailable(removeID, 1);

                initNowSportOutfit();

                i.putExtra("user", currentUser);
                i.putExtra("outfit", myOutfit);
                setResult(RESULT_OK, i);
                finish();
            }
        });
        databaseReference.getRoot().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                numOfUser = dataSnapshot.child("NumOfUser").getValue(Integer.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        out.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent(MyPage.this,MainActivity.class);
                numOfUser -= 1;
                int removeID;
                if(currentUser.getNow().getId() != 0){
                    removeID = currentUser.getNow().getId();
                    removeSportOutfit(removeID);
                    setAvailable(removeID, 1);
                }
                for(int i=0;i<currentUser.getReservationSize();i++){
                    removeID = currentUser.getReservation().get(i).getId();
                    if(removeID != 0){
                        removeSportOutfit(removeID);
                    }
                }
                databaseReference.child("NumOfUser").setValue(numOfUser);
                initNowSportOutfit();
                initReserSportOutfit();

                startActivity(intent);
            }
        });
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(resultCode == RESULT_OK){
            switch(requestCode){
                case MYPAGERESERVATION_ID:
                    int removeID = (int)data.getExtras().getInt("id");
                    for(int i=0;i<currentUser.getReservationSize();i++){
                        if(removeID == currentUser.getReservation().get(i).getId()){
                            removeSportOutfit(removeID);
                            removeReservation(currentUser.getNum(), (i+1));
                        }
                    }
                    for(int i=0;i<adapter.getCount();i++){
                        if(adapter.listViewItemList.get(i).getId() == removeID){
                            adapter.removeItem(i);
                            break;
                        }
                    }
                    adapter.notifyDataSetChanged();
                    break;
            }
        }else if(requestCode == RESULT_CANCELED){
            switch (requestCode) {
                case MYPAGERESERVATION_ID:
                    break;
            }
        }
    }
    public void refresh_my(){
        if(currentUser.getNow().getId() != 0){
            String nName = getOutfitName(currentUser.getNow().getId());
            cnt1.setText(Integer.toString(currentUser.getNow().getCount())+cnt1.getText().toString());
            set1.setText(Integer.toString(currentUser.getNow().getSet())+set1.getText().toString());
            nowName.setText(nName);
        }
        for(int index=0;index<currentUser.getReservationSize();index++){
            adapter.addItem(currentUser.getReservation().get(index).getId(),getOutfitName(currentUser.getReservation().get(index).getId()),String.valueOf(currentUser.getReservation().get(index).getSet()),String.valueOf(currentUser.getReservation().get(index).getCount()));
            adapter.notifyDataSetChanged();
        }
    }
    public void removeReservation(final int user_num, final int reservation_num) {

        databaseReference.getRoot().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (int i = reservation_num + 1; i < 4; i++) {
                    int id;
                    int set;
                    int count;
                    int priority;
                    id = Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user" + user_num).child("reservation" + i).child("id").getValue()));
                    set = Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user" + user_num).child("reservation" + i).child("set").getValue()));
                    count = Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user" + user_num).child("reservation" + i).child("count").getValue()));
                    priority = Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user" + user_num).child("reservation" + i).child("priority").getValue()));
                    databaseReference.child("loginInfo").child("user"+user_num).child("reservation"+(i-1)).child("id").setValue(id);
                    databaseReference.child("loginInfo").child("user"+user_num).child("reservation"+(i-1)).child("set").setValue(set);
                    databaseReference.child("loginInfo").child("user"+user_num).child("reservation"+(i-1)).child("count").setValue(count);
                    databaseReference.child("loginInfo").child("user"+user_num).child("reservation"+(i-1)).child("priority").setValue(priority);

                    databaseReference.child("loginInfo").child("user"+user_num).child("reservation"+(i)).child("id").setValue(0);
                    databaseReference.child("loginInfo").child("user"+user_num).child("reservation"+(i)).child("set").setValue(0);
                    databaseReference.child("loginInfo").child("user"+user_num).child("reservation"+(i)).child("count").setValue(0);
                    databaseReference.child("loginInfo").child("user"+user_num).child("reservation"+(i)).child("priority").setValue(0);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }
    public void removeSportOutfit(int removeID){
        getNumOfOutfit();

        Log.d("numOfOutfit",String.valueOf(numOfOutfit[removeID]));
        databaseReference.child("NumOfOutfit").child(String.valueOf(removeID)).setValue(numOfOutfit[removeID]-1);
        databaseReference.child("SportOutfit").child(String.valueOf(removeID)).child("user"+currentUser.getNum()).removeValue();
        numOfOutfit[removeID]--;
    }
    public void initNowSportOutfit(){
        SportOutfit temp = new SportOutfit(0,0,0,0);
        insertNowSportOutfit(temp);
    }
    public void initReserSportOutfit(){
        SportOutfit temp = new SportOutfit(0,0,0,0);
        ArrayList<SportOutfit> arr_temp = new ArrayList<>();
        arr_temp.add(temp);
        arr_temp.add(temp);
        arr_temp.add(temp);
        insertReserSportOutfit(arr_temp);
    }
    public void insertNowSportOutfit(SportOutfit so){
        databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("now").child("id").setValue(so.getId());
        databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("now").child("set").setValue(so.getSet());
        databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("now").child("count").setValue(so.getCount());
        databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("now").child("priority").setValue(so.getPriority());
    }
    public void insertReserSportOutfit(ArrayList<SportOutfit> arr_so){
        for(int i =0;i<3;i++){
            databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("reservation"+(i+1)).child("id").setValue(arr_so.get(i).getId());
            databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("reservation"+(i+1)).child("set").setValue(arr_so.get(i).getSet());
            databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("reservation"+(i+1)).child("count").setValue(arr_so.get(i).getCount());
            databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("reservation"+(i+1)).child("priority").setValue(arr_so.get(i).getPriority());
        }
    }
    public void getCurrentUser(final int num) {
        databaseReference.getRoot().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //for (DataSnapshot snapshot : dataSnapshot.child("loginInfo").getChildren()) {
                DataSnapshot snapshot = dataSnapshot.child("loginInfo").child("user"+num);
                ArrayList<SportOutfit> arr_temp = new ArrayList<>();
                int id = Integer.parseInt(String.valueOf(snapshot.child("now").child("id").getValue()));
                int set = Integer.parseInt(String.valueOf(snapshot.child("now").child("set").getValue()));
                int count = Integer.parseInt(String.valueOf(snapshot.child("now").child("count").getValue()));
                int priority = Integer.parseInt(String.valueOf(snapshot.child("now").child("priority").getValue()));
                SportOutfit now = new SportOutfit(id, set, count, priority);
                for (int i = 0; i < 3; i++) {
                    id = Integer.parseInt(String.valueOf(snapshot.child("reservation" + (i + 1)).child("id").getValue()));
                    set = Integer.parseInt(String.valueOf(snapshot.child("reservation" + (i + 1)).child("set").getValue()));
                    count = Integer.parseInt(String.valueOf(snapshot.child("reservation" + (i + 1)).child("count").getValue()));
                    priority = Integer.parseInt(String.valueOf(snapshot.child("reservation" + (i + 1)).child("priority").getValue()));
                    SportOutfit temp = new SportOutfit(id, set, count, priority);
                    arr_temp.add(temp);
                }
                currentUser = new User(Integer.parseInt(String.valueOf(snapshot.child("NUM").getValue())), String.valueOf(snapshot.child("ID").getValue()), String.valueOf(snapshot.child("PW").getValue()), now, arr_temp);
                // }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    public void getNumOfOutfit(){
        databaseReference.getRoot().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                numOfOutfit[1] = dataSnapshot.child("NumOfOutfit").child("1").getValue(Integer.class);
                numOfOutfit[2] = dataSnapshot.child("NumOfOutfit").child("2").getValue(Integer.class);
                numOfOutfit[3] = dataSnapshot.child("NumOfOutfit").child("3").getValue(Integer.class);
                numOfOutfit[4] = dataSnapshot.child("NumOfOutfit").child("4").getValue(Integer.class);
                numOfOutfit[5] = dataSnapshot.child("NumOfOutfit").child("5").getValue(Integer.class);
                numOfOutfit[6] = dataSnapshot.child("NumOfOutfit").child("6").getValue(Integer.class);
                numOfOutfit[7] = dataSnapshot.child("NumOfOutfit").child("7").getValue(Integer.class);
                numOfOutfit[8] = dataSnapshot.child("NumOfOutfit").child("8").getValue(Integer.class);
                numOfOutfit[9] = dataSnapshot.child("NumOfOutfit").child("9").getValue(Integer.class);
                numOfOutfit[10] = dataSnapshot.child("NumOfOutfit").child("10").getValue(Integer.class);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }
    public void getAvailable(){
        databaseReference.getRoot().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int index = 1;
                for (DataSnapshot snapshot : dataSnapshot.child("available").getChildren()) {
                    available[index++] = Integer.parseInt(String.valueOf(snapshot.getValue()));
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    public void setAvailable(int id, int value) {
        databaseReference.child("available").child(String.valueOf(id)).setValue(value);
    }
    public String getOutfitName(int id){
        String name = "";
        switch(id){
            case 1:
                name="Incline Bench";
                break;
            case 2:
                name="Chest Press";
                break;
            case 3:
                name="Leg Curl";
                break;
            case 4:
                name="Long Pull";
                break;
            case 5:
                name="Shoulder Press";
                break;
            case 6:
                name = "Bench Press";
                break;
            case 7:
                name = "Machine Fly";
                break;
            case 8:
                name = "Leg Extension";
                break;
            case 9:
                name = "High Fly";
                break;
            case 10:
                name = "Arm Curl";
                break;
            case 0:
                name = "";
        }
        return name;
    }

}
