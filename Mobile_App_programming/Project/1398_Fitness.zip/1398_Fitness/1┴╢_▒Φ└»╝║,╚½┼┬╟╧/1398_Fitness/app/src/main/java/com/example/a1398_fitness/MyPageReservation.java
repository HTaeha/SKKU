package com.example.a1398_fitness;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MyPageReservation extends AppCompatActivity {
    Button cancel, back;
    TextView cnt_view, set_view, nowName;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_page_reservation);

        cancel = (Button) findViewById(R.id.cancel);
        back = (Button) findViewById(R.id.back);
        nowName = (TextView) findViewById(R.id.nowName);
        cnt_view = (TextView) findViewById(R.id.count);
        set_view = (TextView) findViewById(R.id.set);

        final Intent intentResult = new Intent(this.getIntent());

        final int id = intentResult.getExtras().getInt("id");
        String name = intentResult.getExtras().getString("nowName");
        String set = intentResult.getExtras().getString("set");
        String count = intentResult.getExtras().getString("count");

        nowName.setText(name);
        set_view.setText(set);
        cnt_view.setText(count);

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intentResult.putExtra("id",id);
                setResult(RESULT_OK, intentResult);
                finish();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED, intentResult);
                finish();
            }
        });
    }
}
