package com.example.a1398_fitness;

import java.io.Serializable;
import java.util.ArrayList;

public class User implements Serializable {
    int num;
    public String ID;
    public String PW;
    SportOutfit now;
    ArrayList<SportOutfit> reservation = new ArrayList<>();

    public User(int num, String id, String pw, SportOutfit now, ArrayList<SportOutfit>reser){
        this.num = num;
        this.ID = id;
        this.PW = pw;
        this.now = now;
        this.reservation = reser;
    }

    public int getNum() {
        return num;
    }
    public String getID() {
        return ID;
    }
    public String getPW(){
        return PW;
    }

    public SportOutfit getNow() {
        return now;
    }
    public ArrayList<SportOutfit> getReservation() {
        return reservation;
    }
    public void setNum(int num) {
        this.num = num;
    }
    public void setID(String id){
        this.ID = id;
    }
    public void setPW(String pw) {
        this.PW = pw;
    }
    public void setNow(SportOutfit now) {
        this.now = now;
    }
    public void setReservation(ArrayList<SportOutfit> reservation) {
        this.reservation = reservation;
    }
    public void addReservation(SportOutfit so){
        this.reservation.add(so);
    }
    public int getReservationSize(){
        int size = 0;
        for (int i=0;i<reservation.size();i++){
            if(reservation.get(i).getId() != 0){
                size++;
            }
        }
        return size;
    }
}
