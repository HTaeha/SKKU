package com.example.a1398_fitness;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class FirstScreen extends AppCompatActivity {
    TextView num;
    Button enter;
    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference databaseReference = firebaseDatabase.getReference();
    int users;

    User currentUser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_screen);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        num = (TextView) findViewById(R.id.users);
        enter = (Button) findViewById(R.id.enter);

        Intent i = new Intent(this.getIntent());

        currentUser = (User)i.getSerializableExtra("user");
        //Log.d("curUser", String.valueOf(currentUser.getNum()));

        ///////////////////////////헬스장 이용자 수를 알기 위해 users에 그 정보를 담음.
        databaseReference.getRoot().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                users = dataSnapshot.child("NumOfUser").getValue(Integer.class);
                num.setText(num.getText().toString() + Integer.toString(users));
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        //num.setText(num.getText().toString() + users);
        //num.setText(Integer.toString(users));
        //////////////////////////////////////////입장 버튼. 현재 사용중인 사람 수에 대한 정보가 users에 담겨있으므로 1을 늘려주고 db에 저장
        enter.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                Intent intent1 = new Intent(FirstScreen.this, MainPage.class);
                users += 1;
                databaseReference.child("NumOfUser").setValue(users);
                intent1.putExtra("user", currentUser);

                startActivity(intent1);
            }
        });
    }
}
