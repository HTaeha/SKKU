package com.example.a1398_fitness;

import java.io.Serializable;

public class ListViewItem implements Serializable {
    private String nowName;
    private String set;
    private String count;
    private int id;
    public ListViewItem(){
    }
    public ListViewItem(int n, String str1, String str2, String str3){
        id = n;
        nowName = str1;
        set = str2;
        count = str3;
    }

    public int getId() {
        return id;
    }

    public String getNowName() {
        return nowName;
    }

    public String getSet() {
        return set;
    }

    public String getCount() {
        return count;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNowName(String nowName) {
        this.nowName = nowName;
    }

    public void setSet(String set) {
        this.set = set;
    }

    public void setCount(String count) {
        this.count = count;
    }
}
