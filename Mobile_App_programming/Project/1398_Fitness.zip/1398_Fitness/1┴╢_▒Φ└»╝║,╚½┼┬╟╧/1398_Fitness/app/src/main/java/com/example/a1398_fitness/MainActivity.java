package com.example.a1398_fitness;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static final int REQUEST_CODE_ANOTHER = 1001;
    Button login;
    Button join;
    EditText id;
    EditText pw;
    CheckBox autoLogin;
    Boolean loginChecked;


    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference databaseReference = firebaseDatabase.getReference();

    User currentUser;
    ArrayList<User> users = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        login = (Button) findViewById(R.id.login);
        join = (Button) findViewById((R.id.join));
        id = (EditText) findViewById(R.id.id);
        pw = (EditText) findViewById(R.id.pw);
       /* autoLogin = (CheckBox) findViewById(R.id.autoLogin);

        autoLogin.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) {
                    loginChecked = true;
                } else {
                    // if unChecked, removeAll
                    loginChecked = false;
                    //editor.clear();
                    //editor.commit();
                }
            }
        });*/

        join.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                Intent intent1 = new Intent(MainActivity.this, Join.class);

                startActivityForResult(intent1, REQUEST_CODE_ANOTHER);
            }
        });

        databaseReference.getRoot().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot snapshot:dataSnapshot.child("loginInfo").getChildren()){
                    ArrayList<SportOutfit> arr_temp = new ArrayList<>();
                    int id = Integer.parseInt(String.valueOf(snapshot.child("now").child("id").getValue()));
                    int set = Integer.parseInt(String.valueOf(snapshot.child("now").child("set").getValue()));
                    int count = Integer.parseInt(String.valueOf(snapshot.child("now").child("count").getValue()));
                    int priority = Integer.parseInt(String.valueOf(snapshot.child("now").child("priority").getValue()));
                    SportOutfit now = new SportOutfit(id,set,count,priority);
                    for(int i=0;i<3;i++){
                        id = Integer.parseInt(String.valueOf(snapshot.child("reservation"+(i+1)).child("id").getValue()));
                        set = Integer.parseInt(String.valueOf(snapshot.child("reservation"+(i+1)).child("set").getValue()));
                        count = Integer.parseInt(String.valueOf(snapshot.child("reservation"+(i+1)).child("count").getValue()));
                        priority = Integer.parseInt(String.valueOf(snapshot.child("reservation"+(i+1)).child("priority").getValue()));
                        SportOutfit temp = new SportOutfit(id,set,count,priority);
                        arr_temp.add(temp);
                    }
                    users.add(new User(Integer.parseInt(String.valueOf(snapshot.child("NUM").getValue())),String.valueOf(snapshot.child("ID").getValue()), String.valueOf(snapshot.child("PW").getValue()),now, arr_temp));
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String inputid = id.getText().toString();
                String inputpw = pw.getText().toString();

                int check = loginCheck(inputid, inputpw);

                if(check != -1){
                    Toast.makeText(MainActivity.this, "Login Success", Toast.LENGTH_LONG).show();

                    Intent i=new Intent(MainActivity.this,FirstScreen.class);

                    currentUser = users.get(check);
                    i.putExtra("user", currentUser);
                    i.putExtra("channelName", String.valueOf(currentUser.getNum()));
                    startActivity(i);
                }else{
                    Toast.makeText(MainActivity.this, "Login Failed", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        User newUser = (User) data.getSerializableExtra("user");
        if(resultCode == RESULT_OK){
            switch(requestCode){
                case REQUEST_CODE_ANOTHER:
                    users.add(newUser);
                    break;
            }
        }
    }
    private int loginCheck(final String id, final String password){
        for(int i=0;i<users.size();i++){
            if(users.get(i).getID().equals(id) && users.get(i).getPW().equals(password)){
                return i;
            }
        }
        return -1;
    }

}