package com.example.a1398_fitness;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.io.Serializable;
import java.util.ArrayList;

public class ListViewAdapter extends BaseAdapter implements Serializable {
    public ArrayList<ListViewItem> listViewItemList = new ArrayList<ListViewItem>() ;

    public ListViewAdapter() {

    }

    @Override
    public int getCount() {
        return listViewItemList.size() ;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;
        final Context context = parent.getContext();

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.listview_item, parent, false);
        }

        TextView nowName = (TextView) convertView.findViewById(R.id.nowName) ;
        TextView set = convertView.findViewById(R.id.set);
        TextView count = (TextView) convertView.findViewById(R.id.count) ;


        ListViewItem listViewItem = listViewItemList.get(position);
        nowName.setText(listViewItem.getNowName());
        set.setText(listViewItem.getSet()+"세트");
        count.setText(listViewItem.getCount()+"회");

        return convertView;
    }

    @Override
    public long getItemId(int position) {
        return position ;
    }

    @Override
    public Object getItem(int position) {
        return listViewItemList.get(position) ;
    }

    public void addItem(int id,String name, String set, String count) {
        ListViewItem item = new ListViewItem();

        item.setId(id);
        item.setNowName(name);
        item.setSet(set);
        item.setCount(count);

        listViewItemList.add(item);
    }
    public void removeItem(int index){
        listViewItemList.remove(index);
    }
    public void setItem(int index, ListViewItem item){
        listViewItemList.set(index, item);
    }
    public void clear(){
        listViewItemList.clear();
    }

}