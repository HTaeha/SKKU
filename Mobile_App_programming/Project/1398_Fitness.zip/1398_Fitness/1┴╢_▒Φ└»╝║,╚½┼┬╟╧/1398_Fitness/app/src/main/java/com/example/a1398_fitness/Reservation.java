package com.example.a1398_fitness;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Reservation extends AppCompatActivity {
    Button reser;
    EditText count;
    EditText set;
    TextView name;
    int n;
    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference databaseReference = firebaseDatabase.getReference();
    int user_num;
    User currentUser;
    int currentNum;
    boolean now;
    int[] available = new int[11];
    int[] numOfOutfit = new int[11];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reservation);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
/////////////////////////////////////////////////////////////////////////////////////////////////////
        reser = (Button) findViewById(R.id.reser);
        count = (EditText) findViewById(R.id.count);
        set = (EditText) findViewById(R.id.set);
        name = (TextView) findViewById(R.id.name);

        final Intent i = new Intent(this.getIntent());

        n = i.getExtras().getInt("id");
        currentUser = (User)i.getSerializableExtra("user");
        now = i.getExtras().getBoolean("now");
        currentNum = currentUser.getNum();
///////////////////////////////////////////////////////사용할 기구의 사용자 수를 받아옴
        databaseReference.getRoot().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                user_num = dataSnapshot.child("NumOfOutfit").child(Integer.toString(n)).getValue(Integer.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
//////////////////////////////////////////////////////id에 따른 기구 이름 출력
        switch(n){
            case 1:
                name.setText("Incline Bench");
                break;
            case 2:
                name.setText("Chest Press");
                break;
            case 3:
                name.setText("Leg Curl");
                break;
            case 4:
                name.setText("Long Pull");
                break;
            case 5:
                name.setText("Shoulder Press");
                break;
            case 6:
                name.setText("Bench Press");
                break;
            case 7:
                name.setText("Machine Fly");
                break;
            case 8:
                name.setText("Leg Extension");
                break;
            case 9:
                name.setText("High Fly");
                break;
            case 10:
                name.setText("Arm Curl");
                break;
        }
/////////////////////////////////////////예약 버튼을 누르면 해당 기구의 사용자 수를 1 늘려주고 기구 id, 횟수, 세트수에 대한 정보를 다음 페이지로 넘겨줌
        reser.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view) {
                getNumOfOutfit();
                getAvailable();
                user_num += 1;
                int priority;
                databaseReference.child("NumOfOutfit").child(Integer.toString(n)).setValue(user_num);
                if (now) {
                    databaseReference.child("SportOutfit").child(String.valueOf(n)).child("user" + currentNum).child("priority").setValue(3);
                } else {
                    if (numOfOutfit[n] == 0) {
                        priority = 2;
                    } else {
                        priority = 3 - numOfOutfit[n];
                    }
                    databaseReference.child("SportOutfit").child(String.valueOf(n)).child("user" + currentNum).child("priority").setValue(priority);
                }
                databaseReference.child("SportOutfit").child(String.valueOf(n)).child("user" + currentNum).child("NUM").setValue(currentUser.getNum());
                i.putExtra("user", currentUser);
                i.putExtra("id", n);
                i.putExtra("count", Integer.parseInt(count.getText().toString()));
                i.putExtra("set", Integer.parseInt(set.getText().toString()));
                i.putExtra("now", now);

                setResult(RESULT_OK, i);
                finish();
            }
        });

    }
    public void getNumOfOutfit(){
        databaseReference.getRoot().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                numOfOutfit[1] = dataSnapshot.child("NumOfOutfit").child("1").getValue(Integer.class);
                numOfOutfit[2] = dataSnapshot.child("NumOfOutfit").child("2").getValue(Integer.class);
                numOfOutfit[3] = dataSnapshot.child("NumOfOutfit").child("3").getValue(Integer.class);
                numOfOutfit[4] = dataSnapshot.child("NumOfOutfit").child("4").getValue(Integer.class);
                numOfOutfit[5] = dataSnapshot.child("NumOfOutfit").child("5").getValue(Integer.class);
                numOfOutfit[6] = dataSnapshot.child("NumOfOutfit").child("6").getValue(Integer.class);
                numOfOutfit[7] = dataSnapshot.child("NumOfOutfit").child("7").getValue(Integer.class);
                numOfOutfit[8] = dataSnapshot.child("NumOfOutfit").child("8").getValue(Integer.class);
                numOfOutfit[9] = dataSnapshot.child("NumOfOutfit").child("9").getValue(Integer.class);
                numOfOutfit[10] = dataSnapshot.child("NumOfOutfit").child("10").getValue(Integer.class);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }
    public void getAvailable(){
        databaseReference.getRoot().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int index = 1;
                for (DataSnapshot snapshot : dataSnapshot.child("available").getChildren()) {
                    available[index++] = Integer.parseInt(String.valueOf(snapshot.getValue()));
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}
