package com.example.a1398_fitness;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class MainPage extends AppCompatActivity {
    ImageView r1, r2, r3, r4, r5;
    ImageView bench, mfly, legex, highfly, armcurl;
    TextView r1use, r2use, r3use, r4use, r5use, l1use, l2use, l3use, l4use, l5use;
    private FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    private DatabaseReference databaseReference = firebaseDatabase.getReference();
    Button mp, out;
    int mannum;
    int[] numOfOutfit = new int[11];
    User currentUser;
    int[] available = new int[11];

    public static final int RESERVATION_ID = 100;
    public static final int MYPAGE_ID = 200;
    private final String CHANNEL_ID = "channel_id";
    int notification_count = 0;
    ArrayList<SportOutfit> myOutfit = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });



        r1use = (TextView) findViewById(R.id.r1use);
        r2use = (TextView) findViewById(R.id.r2use);
        r3use = (TextView) findViewById(R.id.r3use);
        r4use = (TextView) findViewById(R.id.r4use);
        r5use = (TextView) findViewById(R.id.r5use);
        l1use = (TextView) findViewById(R.id.l1use);
        l2use = (TextView) findViewById(R.id.l2use);
        l3use = (TextView) findViewById(R.id.l3use);
        l4use = (TextView) findViewById(R.id.l4use);
        l5use = (TextView) findViewById(R.id.l5use);
        mp = (Button) findViewById(R.id.mypage);
        //out = (Button) findViewById(R.id.out);

        Intent i = new Intent(this.getIntent());

        currentUser = (User)i.getSerializableExtra("user");

        createNotificationChannel();

        refresh(currentUser.getNum());
        Thread th = new Thread(new Runnable() {
            @Override
            public void run() {
                int Num = 1;
                while (true) {
                    //Log.i("Thread", "" + Num);
                    //Log.i("current", currentUser.getID());
                    //Num++;
                    refresh(currentUser.getNum());

                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
        th.start();

        r1 = (ImageView) findViewById(R.id.running1);
        r2 = (ImageView) findViewById(R.id.running2);
        r3 = (ImageView) findViewById(R.id.running3);
        r4 = (ImageView) findViewById(R.id.running4);
        r5 = (ImageView) findViewById(R.id.running5);

        bench = (ImageView) findViewById(R.id.bench);
        mfly = (ImageView) findViewById(R.id.mFly);
        legex = (ImageView) findViewById(R.id.legEx);
        highfly = (ImageView) findViewById(R.id.highFly);
        armcurl = (ImageView) findViewById(R.id.armCurl);

        r1.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                reservationAction(1);
            }
        });
        r2.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                reservationAction(2);
            }
        });
        r3.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                reservationAction(3);
            }
        });
        r4.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                reservationAction(4);
            }
        });
        r5.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                reservationAction(5);
            }
        });
        bench.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                reservationAction(6);
            }
        });
        mfly.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                reservationAction(7);
            }
        });
        legex.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                reservationAction(8);
            }
        });
        highfly.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                reservationAction(9);
            }
        });
        armcurl.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                reservationAction(10);
            }
        });
        mp.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                refresh(currentUser.getNum());
                Intent intent = new Intent(MainPage.this,MyPage.class);
                intent.putExtra("user", currentUser);
                intent.putExtra("outfit", myOutfit);

                startActivityForResult(intent, MYPAGE_ID);
            }
        });

        databaseReference.getRoot().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                mannum = dataSnapshot.child("NumOfUser").getValue(Integer.class);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(resultCode == RESULT_OK){
            switch(requestCode){
                case RESERVATION_ID:
                    currentUser = (User) data.getSerializableExtra("user");
                    int id = data.getExtras().getInt("id");
                    int count = data.getExtras().getInt("count");
                    int set = data.getExtras().getInt("set");
                    boolean now = data.getExtras().getBoolean("now");
                    int priority;
                    SportOutfit temp = null;

                    if(now){
                        priority = 3;
                        temp = new SportOutfit(id, count, set, priority);
                        currentUser.setNow(temp);
                        available[id] = 0;
                        setAvailable(id, 0);
                        insertNowSportOutfit(temp);
                    }else{
                        if(numOfOutfit[id] == 0){
                            priority = 2;
                        }else{
                            priority = 3-numOfOutfit[id];
                        }
                        //priority = 3 - numOfOutfit[id];
                        temp = new SportOutfit(id, count, set, priority);
                        currentUser.addReservation(temp);
                        addReserSportOutfit(temp);
                    }
                    myOutfit.add(temp);

                    refresh(currentUser.getNum());
                    break;
                case MYPAGE_ID:
                    currentUser = (User) data.getSerializableExtra("user");
                    myOutfit.clear();
                    myOutfit = (ArrayList<SportOutfit>) data.getSerializableExtra("outfit");
                    break;
            }
        }
    }
    public synchronized void refresh(int num){
        getCurrentUser(num);
        getAvailable();
        getNumOfOutfit();
        check();
        databaseReference.getRoot().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                r1use.setText((numOfOutfit[1])+" /"+r1use.getText().toString().split("/")[1]);
                r2use.setText((numOfOutfit[2])+" /"+r2use.getText().toString().split("/")[1]);
                r3use.setText((numOfOutfit[3])+" /"+r3use.getText().toString().split("/")[1]);
                r4use.setText((numOfOutfit[4])+" /"+r4use.getText().toString().split("/")[1]);
                r5use.setText((numOfOutfit[5])+" /"+r5use.getText().toString().split("/")[1]);
                l1use.setText((numOfOutfit[6])+" /"+l1use.getText().toString().split("/")[1]);
                l2use.setText((numOfOutfit[7])+" /"+l2use.getText().toString().split("/")[1]);
                l3use.setText((numOfOutfit[8])+" /"+l3use.getText().toString().split("/")[1]);
                l4use.setText((numOfOutfit[9])+" /"+l4use.getText().toString().split("/")[1]);
                l5use.setText((numOfOutfit[10])+" /"+l5use.getText().toString().split("/")[1]);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }

    public void check() {

        databaseReference.getRoot().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int i;
                int user_num = 0;
                int priority;
                boolean flag;
                for (i = 1; i < 11; i++) {
                    if (available[i] == 1) {
                        flag = true;
                        for (DataSnapshot snapshot : dataSnapshot.child("SportOutfit").child(String.valueOf(i)).getChildren()) {
                            priority = Integer.parseInt(String.valueOf(snapshot.child("priority").getValue()));
                            if(priority == 3){ //사용중인 사람 있음.
                                flag = false;
                                break;
                            }
                        }
                        if(flag){ //사용 가능하지만 사용중인 사람 없음.
                            int user_num2=0;
                            int priority2=0;
                            int user_num1=0;
                            int priority1=0;
                            for (DataSnapshot snapshot : dataSnapshot.child("SportOutfit").child(String.valueOf(i)).getChildren()) {
                                user_num = Integer.parseInt(String.valueOf(snapshot.child("NUM").getValue()));              //예약한 사람 number.
                                priority = Integer.parseInt(String.valueOf(snapshot.child("priority").getValue()));         //예약한 사람 priority.
                                if(priority == 2){
                                    user_num2 = user_num;
                                    priority2 = priority;
                                }else if(priority == 1){
                                    user_num1 = user_num;
                                    priority1 = priority;
                                }
                            }
                            if(user_num2 != 0 && user_num2 == currentUser.getNum()){
                                Log.d("sportOutfit", String.valueOf(i));
                                Log.d("user num2", String.valueOf(user_num2));
                                Log.d("cur Num", String.valueOf(currentUser.getNum()));
                                if(Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user"+user_num2).child("now").child("priority").getValue())) != 3){
                                    //change
                                    //기구 priority 3으로 바꾸고 그 기구에 대한 다른 예약자들 priority 1씩 올림. loginInfo 에서 now에 새로 올리고 reservation 하나씩 땡김. priotiry 올라간 다른 사람들도 loginInfo 변경.
                                    //SportOutfit, availiable, loginInfo
                                    //notification
                                    setAvailable(i, 0);
                                    int reservation_num=0;
                                    for (DataSnapshot snapshot : dataSnapshot.child("loginInfo").child("user"+user_num2).getChildren()) {
                                        String reservation = String.valueOf(snapshot.getKey());
                                        if(reservation.equals("reservation1")){
                                            if(snapshot.child("id").getValue(Integer.class) == i){
                                                reservation_num = 1;
                                                break;
                                            }
                                        }else if(reservation.equals("reservation2")){
                                            if(snapshot.child("id").getValue(Integer.class) == i){
                                                reservation_num = 2;
                                                break;
                                            }
                                        }else if(reservation.equals("reservation3")){
                                            if(snapshot.child("id").getValue(Integer.class) == i){
                                                reservation_num = 3;
                                                break;
                                            }
                                        }
                                    }
                                    int id_now = Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user"+user_num2).child("reservation"+reservation_num).child("id").getValue()));
                                    int set_now= Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user"+user_num2).child("reservation"+reservation_num).child("set").getValue()));
                                    int count_now= Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user"+user_num2).child("reservation"+reservation_num).child("count").getValue()));
                                    int priority_now= Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user"+user_num2).child("reservation"+reservation_num).child("priority").getValue()));
                                    databaseReference.child("loginInfo").child("user"+user_num2).child("now").child("id").setValue(id_now);
                                    databaseReference.child("loginInfo").child("user"+user_num2).child("now").child("set").setValue(set_now);
                                    databaseReference.child("loginInfo").child("user"+user_num2).child("now").child("count").setValue(count_now);
                                    databaseReference.child("loginInfo").child("user"+user_num2).child("now").child("priority").setValue(3);
                                    removeReservation(user_num2, reservation_num);

                                    databaseReference.child("SportOutfit").child(String.valueOf(i)).child("user"+user_num2).child("priority").setValue(3);
                                    for (DataSnapshot snapshot : dataSnapshot.child("SportOutfit").child(String.valueOf(i)).getChildren()) {
                                        String changed_user = String.valueOf(snapshot.getKey());
                                        if(!changed_user.equals("user"+user_num2)){
                                            int changed_user_num = Integer.parseInt(String.valueOf(snapshot.child("NUM").getValue()));
                                            int changed_user_prior = Integer.parseInt(String.valueOf(snapshot.child("priority").getValue()));
                                            changed_user_prior++;
                                            databaseReference.child("SportOutfit").child(String.valueOf(i)).child("user"+changed_user_num).child("priority").setValue(changed_user_prior);
                                            int changed_reservation_num=0;
                                            for (DataSnapshot snapshot2 : dataSnapshot.child("loginInfo").child("user"+changed_user_num).getChildren()) {
                                                String reservation = String.valueOf(snapshot.getKey());
                                                if(reservation.equals("reservation1")){
                                                    if(snapshot2.child("id").getValue(Integer.class) == i){
                                                        changed_reservation_num = 1;
                                                        break;
                                                    }
                                                }else if(reservation.equals("reservation2")){
                                                    if(snapshot2.child("id").getValue(Integer.class) == i){
                                                        changed_reservation_num = 2;
                                                        break;
                                                    }
                                                }else if(reservation.equals("reservation3")){
                                                    if(snapshot2.child("id").getValue(Integer.class) == i){
                                                        changed_reservation_num = 3;
                                                        break;
                                                    }
                                                }
                                            }
                                            databaseReference.child("loginInfo").child("user"+changed_user_num).child("reservation"+changed_reservation_num).child("priority").setValue(changed_user_prior);
                                        }
                                    }
                                    //Log.d("user num2", String.valueOf(user_num2));
                                    //Log.d("cur Num", String.valueOf(currentUser.getNum()));
                                    if(currentUser.getNum() == user_num2){
                                        addNotification(getOutfitName(i),"이용 가능합니다.",++notification_count);
                                        Toast.makeText(getBaseContext(), getOutfitName(i)+"이용 가능합니다.", Toast.LENGTH_LONG).show();
                                    }
                                }
                            }else if(user_num1 != 0 && user_num1 == currentUser.getNum()){
                                Log.d("user num1", String.valueOf(user_num1));
                                Log.d("cur Num", String.valueOf(currentUser.getNum()));
                                if(Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user"+user_num1).child("now").child("priority").getValue())) != 3){
                                    //change
                                    //기구 priority 3으로 바꾸고 그 기구에 대한 다른 예약자들 priority 1씩 올림. loginInfo 에서 now에 새로 올리고 reservation 하나씩 땡김. priotiry 올라간 다른 사람들도 loginInfo 변경.
                                    //SportOutfit, availiable, loginInfo
                                    //notification
                                    setAvailable(i, 0);
                                    int reservation_num=0;
                                    for (DataSnapshot snapshot : dataSnapshot.child("loginInfo").child("user"+user_num1).getChildren()) {
                                        String reservation = String.valueOf(snapshot.getKey());
                                        if(reservation.equals("reservation1")){
                                            if(snapshot.child("id").getValue(Integer.class) == i){
                                                reservation_num = 1;
                                                break;
                                            }
                                        }else if(reservation.equals("reservation2")){
                                            if(snapshot.child("id").getValue(Integer.class) == i){
                                                reservation_num = 2;
                                                break;
                                            }
                                        }else if(reservation.equals("reservation3")){
                                            if(snapshot.child("id").getValue(Integer.class) == i){
                                                reservation_num = 3;
                                                break;
                                            }
                                        }
                                    }
                                    int id_now = Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user"+user_num1).child("reservation"+reservation_num).child("id").getValue()));
                                    int set_now= Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user"+user_num1).child("reservation"+reservation_num).child("set").getValue()));
                                    int count_now= Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user"+user_num1).child("reservation"+reservation_num).child("count").getValue()));
                                    int priority_now= Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user"+user_num1).child("reservation"+reservation_num).child("priority").getValue()));
                                    databaseReference.child("loginInfo").child("user"+user_num1).child("now").child("id").setValue(id_now);
                                    databaseReference.child("loginInfo").child("user"+user_num1).child("now").child("set").setValue(set_now);
                                    databaseReference.child("loginInfo").child("user"+user_num1).child("now").child("count").setValue(count_now);
                                    databaseReference.child("loginInfo").child("user"+user_num1).child("now").child("priority").setValue(3);
                                    removeReservation(user_num1, reservation_num);

                                    databaseReference.child("SportOutfit").child(String.valueOf(i)).child("user"+user_num1).child("priority").setValue(3);
                                    if(currentUser.getNum() == user_num1){
                                        addNotification(getOutfitName(currentUser.getNow().getId()),"이용 가능합니다.",++notification_count);
                                        Toast.makeText(getBaseContext(), getOutfitName(i)+"이용 가능합니다.", Toast.LENGTH_LONG).show();
                                    }
                                }
                            }
                        }
                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }
    public String getOutfitName(int id){
        String name = "";
        switch(id){
            case 1:
                name="Incline Bench";
                break;
            case 2:
                name="Chest Press";
                break;
            case 3:
                name="Leg Curl";
                break;
            case 4:
                name="Long Pull";
                break;
            case 5:
                name="Shoulder Press";
                break;
            case 6:
                name = "Bench Press";
                break;
            case 7:
                name = "Machine Fly";
                break;
            case 8:
                name = "Leg Extension";
                break;
            case 9:
                name = "High Fly";
                break;
            case 10:
                name = "Arm Curl";
                break;
            case 0:
                name = "";
        }
        return name;
    }
    private void addNotification(String notify_title, String notify_content, int id){
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this,CHANNEL_ID)
                .setSmallIcon(R.drawable.bench)
                .setContentTitle(notify_title)
                .setContentText(notify_content)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);
        NotificationManager manager =
                (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        manager.notify(id,builder.build());
    }
    private void removeAllNotification(){
        NotificationManager manager =
                (NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        manager.cancelAll();
    }
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = getString(R.string.channel_name);
            String description = getString(R.string.channel_description);
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            //NotificationChannel channel = new NotificationChannel(String.valueOf(channelID), name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager =
                    getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }
    public void removeReservation(final int user_num, final int reservation_num) {

        databaseReference.getRoot().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (int i = reservation_num + 1; i < 4; i++) {
                    int id;
                    int set;
                    int count;
                    int priority;
                    id = Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user" + user_num).child("reservation" + i).child("id").getValue()));
                    set = Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user" + user_num).child("reservation" + i).child("set").getValue()));
                    count = Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user" + user_num).child("reservation" + i).child("count").getValue()));
                    priority = Integer.parseInt(String.valueOf(dataSnapshot.child("loginInfo").child("user" + user_num).child("reservation" + i).child("priority").getValue()));
                    databaseReference.child("loginInfo").child("user"+user_num).child("reservation"+(i-1)).child("id").setValue(id);
                    databaseReference.child("loginInfo").child("user"+user_num).child("reservation"+(i-1)).child("set").setValue(set);
                    databaseReference.child("loginInfo").child("user"+user_num).child("reservation"+(i-1)).child("count").setValue(count);
                    databaseReference.child("loginInfo").child("user"+user_num).child("reservation"+(i-1)).child("priority").setValue(priority);

                    databaseReference.child("loginInfo").child("user"+user_num).child("reservation"+(i)).child("id").setValue(0);
                    databaseReference.child("loginInfo").child("user"+user_num).child("reservation"+(i)).child("set").setValue(0);
                    databaseReference.child("loginInfo").child("user"+user_num).child("reservation"+(i)).child("count").setValue(0);
                    databaseReference.child("loginInfo").child("user"+user_num).child("reservation"+(i)).child("priority").setValue(0);
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }
    public void getNumOfOutfit(){
        databaseReference.getRoot().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                numOfOutfit[1] = dataSnapshot.child("NumOfOutfit").child("1").getValue(Integer.class);
                numOfOutfit[2] = dataSnapshot.child("NumOfOutfit").child("2").getValue(Integer.class);
                numOfOutfit[3] = dataSnapshot.child("NumOfOutfit").child("3").getValue(Integer.class);
                numOfOutfit[4] = dataSnapshot.child("NumOfOutfit").child("4").getValue(Integer.class);
                numOfOutfit[5] = dataSnapshot.child("NumOfOutfit").child("5").getValue(Integer.class);
                numOfOutfit[6] = dataSnapshot.child("NumOfOutfit").child("6").getValue(Integer.class);
                numOfOutfit[7] = dataSnapshot.child("NumOfOutfit").child("7").getValue(Integer.class);
                numOfOutfit[8] = dataSnapshot.child("NumOfOutfit").child("8").getValue(Integer.class);
                numOfOutfit[9] = dataSnapshot.child("NumOfOutfit").child("9").getValue(Integer.class);
                numOfOutfit[10] = dataSnapshot.child("NumOfOutfit").child("10").getValue(Integer.class);
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }
    public void insertNowSportOutfit(SportOutfit so){
        databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("now").child("id").setValue(so.getId());
        databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("now").child("set").setValue(so.getSet());
        databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("now").child("count").setValue(so.getCount());
        databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("now").child("priority").setValue(so.getPriority());
    }
    public void insertReserSportOutfit(ArrayList<SportOutfit> arr_so){
        for(int i =0;i<3;i++){
            databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("reservation"+(i+1)).child("id").setValue(arr_so.get(i).getId());
            databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("reservation"+(i+1)).child("set").setValue(arr_so.get(i).getSet());
            databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("reservation"+(i+1)).child("count").setValue(arr_so.get(i).getCount());
            databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("reservation"+(i+1)).child("priority").setValue(arr_so.get(i).getPriority());
        }
    }
    public void addReserSportOutfit(SportOutfit so){
        for(int i =0;i<3;i++) {
            if(currentUser.getReservation().get(i).getId() == 0){
                databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("reservation"+(i+1)).child("id").setValue(so.getId());
                databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("reservation"+(i+1)).child("set").setValue(so.getSet());
                databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("reservation"+(i+1)).child("count").setValue(so.getCount());
                databaseReference.child("loginInfo").child("user"+currentUser.getNum()).child("reservation"+(i+1)).child("priority").setValue(so.getPriority());
                break;
            }
        }
    }
    public void getCurrentUser(final int num) {
        databaseReference.getRoot().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                //for (DataSnapshot snapshot : dataSnapshot.child("loginInfo").getChildren()) {
                DataSnapshot snapshot = dataSnapshot.child("loginInfo").child("user"+num);
                    ArrayList<SportOutfit> arr_temp = new ArrayList<>();
                    int id = Integer.parseInt(String.valueOf(snapshot.child("now").child("id").getValue()));
                    int set = Integer.parseInt(String.valueOf(snapshot.child("now").child("set").getValue()));
                    int count = Integer.parseInt(String.valueOf(snapshot.child("now").child("count").getValue()));
                    int priority = Integer.parseInt(String.valueOf(snapshot.child("now").child("priority").getValue()));
                    SportOutfit now = new SportOutfit(id, set, count, priority);
                    for (int i = 0; i < 3; i++) {
                        id = Integer.parseInt(String.valueOf(snapshot.child("reservation" + (i + 1)).child("id").getValue()));
                        set = Integer.parseInt(String.valueOf(snapshot.child("reservation" + (i + 1)).child("set").getValue()));
                        count = Integer.parseInt(String.valueOf(snapshot.child("reservation" + (i + 1)).child("count").getValue()));
                        priority = Integer.parseInt(String.valueOf(snapshot.child("reservation" + (i + 1)).child("priority").getValue()));
                        SportOutfit temp = new SportOutfit(id, set, count, priority);
                        arr_temp.add(temp);
                    }
                    currentUser = new User(Integer.parseInt(String.valueOf(snapshot.child("NUM").getValue())), String.valueOf(snapshot.child("ID").getValue()), String.valueOf(snapshot.child("PW").getValue()), now, arr_temp);
               // }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    public void getAvailable(){
        databaseReference.getRoot().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int index = 1;
                for (DataSnapshot snapshot : dataSnapshot.child("available").getChildren()) {
                    available[index++] = Integer.parseInt(String.valueOf(snapshot.getValue()));
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    public void setAvailable(int id, int value) {
        databaseReference.child("available").child(String.valueOf(id)).setValue(value);
    }
    public void reservationAction(int outfit){
        Intent intent = new Intent(MainPage.this,Reservation.class);
        if(numOfOutfit[outfit]<3) {
            if(currentUser.getReservationSize() >= 3){
                Toast.makeText(getBaseContext(), "최대 3개까지 예약할 수 있습니다. ", Toast.LENGTH_LONG).show();
                return;
            }
            if(currentUser.getNow().getId() == outfit){
                Toast.makeText(getBaseContext(), "사용 중인 기구는 예약할 수 없습니다. ", Toast.LENGTH_LONG).show();
                return;
            }
            for(int i=0;i<currentUser.getReservationSize();i++){
                if(currentUser.getReservation().get(i).getId() == outfit){
                    Toast.makeText(getBaseContext(), "예약 대기 중인 기구는 예약할 수 없습니다. ", Toast.LENGTH_LONG).show();
                    return;
                }
            }
            boolean now;

            if(available[outfit] == 1){
                if(currentUser.getNow().getId() != 0){
                    now = false;
                }else{
                    now = true;
                }
            }else{
                now = false;
            }
            intent.putExtra("id", outfit);
            intent.putExtra("user", currentUser);
            intent.putExtra("now",now);
            startActivityForResult(intent, RESERVATION_ID);
        }else{
            Toast.makeText(getBaseContext(), "Already Full", Toast.LENGTH_LONG).show();
        }
    }
}
