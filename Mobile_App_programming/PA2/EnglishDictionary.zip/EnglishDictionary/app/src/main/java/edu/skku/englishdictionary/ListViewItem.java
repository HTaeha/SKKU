package edu.skku.englishdictionary;

import java.io.Serializable;

public class ListViewItem implements Serializable {
    private String type;
    private String keyword;
    private String content;
    public ListViewItem(){
    }
    public ListViewItem(String str1, String str2, String str3){
        type = str1;
        keyword = str2;
        content = str3;
    }
    public String getType(){
        return type;
    }
    public String getKeyword(){
        return keyword;
    }
    public String getContent() {
        return content;
    }
    public void setType(String str){
        type = str;
    }
    public void setKeyword(String str){
        keyword = str;
    }
    public void setContent(String str){
        content = str;
    }
}
