package edu.skku.englishdictionary;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class HistorySubActivity extends AppCompatActivity {
    ListViewAdapter adapter = new ListViewAdapter();
    Button exit;
    Button remove;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sub_history_view);

        final Intent intentResult = new Intent(this.getIntent());
        ArrayList<String> receiveData = new ArrayList<>();
        String keyword;
        receiveData = (ArrayList<String>) intentResult.getSerializableExtra("data");
        keyword = receiveData.get(1);
        final int position = Integer.parseInt(receiveData.get(0));

        ListView listview = (ListView) findViewById(R.id.listview);
        exit = (Button)findViewById(R.id.exit);
        remove = (Button)findViewById(R.id.remove_btn);

        listview.setAdapter(adapter);
        try {
            if(isExternalStorageReadable()) {
                ArrayList<ListViewItem> item = readCSV(keyword);
                adapter.clear();
                for(int i=0;i<item.size();i++){
                    adapter.addItem(item.get(i).getType(),item.get(i).getKeyword(), item.get(i).getContent());
                    adapter.notifyDataSetChanged();
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        final ListViewItem[] history = {new ListViewItem()};
        final ArrayList<String> sendData = new ArrayList<String>();
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                final Intent i=new Intent(HistorySubActivity.this,HistorySub2Activity.class);
                sendData.clear();
                sendData.add(String.valueOf(position));
                history[0] = (ListViewItem) adapter.getItem(position);
                sendData.add(history[0].getType());
                sendData.add(history[0].getKeyword());
                sendData.add(history[0].getContent());
                i.putExtra("data", sendData);
                startActivity(i);
            }
        });

        exit.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                setResult(RESULT_CANCELED, intentResult);
                finish();
            }
        });
        remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                intentResult.putExtra("result", position);
                setResult(RESULT_OK, intentResult);
                finish();
            }
        });
    }
    public ArrayList<ListViewItem> readCSV(String keyword) throws IOException {
        char csvName = (Character.toLowerCase(keyword.charAt(0)));

        File fileDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File fileToGet = new File(fileDirectory,csvName+".csv");
        BufferedReader br = new BufferedReader(new FileReader(fileToGet));
        String line;
        String[] tokens = null;
        String dict_key="";
        ArrayList<ListViewItem> result = new ArrayList<>();
        int index = 0;
        while ((line = br.readLine()) !=null) {
            tokens = line.split(" ");
            dict_key = tokens[0].replaceAll("\"", "");
            if (dict_key.toLowerCase().startsWith(keyword.toLowerCase())){
                ListViewItem temp = null;

                String[] type_token_1 = line.split("\\(");
                String type = type_token_1[1].split("\\)")[0];

                String[] content_token = line.split("\\)");
                String content = "";
                for (int i=1;i<content_token.length;i++){
                    content += content_token[i];
                }
                temp = new ListViewItem(type, dict_key, content);
                result.add(temp);
            }
            if(index == 5){
                break;
            }
        }
        return result;
    }
    public boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state) || Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            return true;
        }
        return false;
    }
}
