package edu.skku.englishdictionary;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.io.Serializable;
import java.util.ArrayList;

public class ListViewAdapter extends BaseAdapter implements Serializable {
    public ArrayList<ListViewItem> listViewItemList = new ArrayList<ListViewItem>() ;

    public ListViewAdapter() {

    }

    @Override
    public int getCount() {
        return listViewItemList.size() ;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        final int pos = position;
        final Context context = parent.getContext();

        if (convertView == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(R.layout.listview_item, parent, false);
        }

        TextView typeView = (TextView) convertView.findViewById(R.id.number) ;
        TextView keywordView = (TextView) convertView.findViewById(R.id.textView) ;

        ListViewItem listViewItem = listViewItemList.get(position);

        typeView.setText(listViewItem.getType());
        keywordView.setText(listViewItem.getKeyword());

        return convertView;
    }

    @Override
    public long getItemId(int position) {
        return position ;
    }

    @Override
    public Object getItem(int position) {
        return listViewItemList.get(position) ;
    }

    public void addItem(String type, String keyword, String content) {
        ListViewItem item = new ListViewItem();

        item.setType(type);
        item.setKeyword(keyword);
        item.setContent(content);

        listViewItemList.add(item);
    }
    public void removeItem(int index){
        listViewItemList.remove(index);
    }
    public void setItem(int index, ListViewItem item){
        listViewItemList.set(index, item);
    }
    public void clear(){
        listViewItemList.clear();
    }
    public void print(){
        for(int i=0;i<listViewItemList.size();i++){
            Log.d("item", listViewItemList.get(i).getKeyword());
        }
    }
}