package edu.skku.englishdictionary;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.sql.BatchUpdateException;
import java.util.ArrayList;

public class BookmarkSubActivity extends AppCompatActivity {
    TextView type;
    TextView key;
    TextView content;

    Button exit;
    Button remove;

    private ArrayList<String> result = new ArrayList<String>();
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sub_bookmark_view);

        final Intent intentResult = new Intent(this.getIntent());
        ArrayList<String> arrayList;
        arrayList = (ArrayList<String>) intentResult.getSerializableExtra("data");
        final String position = arrayList.get(0);

        type = (TextView)findViewById(R.id.type);
        key = (TextView)findViewById(R.id.key);
        content = (TextView)findViewById(R.id.content);
        type.setText(arrayList.get(1));
        key.setText(arrayList.get(2));
        content.setText(arrayList.get(3));

        exit = (Button)findViewById(R.id.exit);
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setResult(RESULT_CANCELED, intentResult);
                finish();
            }
        });

        remove = (Button)findViewById(R.id.remove_btn);
        remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                result.add(position);
                intentResult.putExtra("result", result);
                setResult(RESULT_OK, intentResult);
                finish();
            }
        });

    }
}
