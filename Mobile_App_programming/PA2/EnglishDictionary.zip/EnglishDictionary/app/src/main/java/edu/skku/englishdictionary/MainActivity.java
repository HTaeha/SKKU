package edu.skku.englishdictionary;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    Button Search_btn;
    Button History_btn;
    Button Bookmark_btn;

    private ArrayList<String> history_arrlist = new ArrayList<String>();
    private ArrayList<ListViewItem> bookmark_arrlist = new ArrayList<ListViewItem>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Search_btn = (Button)findViewById(R.id.search);
        History_btn = (Button)findViewById(R.id.history);
        Bookmark_btn = (Button)findViewById(R.id.bookmark);

        Search_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent i= new Intent(MainActivity.this, SearchActivity.class);
                startActivityForResult(i, 100);
            }
        });
        History_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent i= new Intent(MainActivity.this, HistoryActivity.class);
                i.putExtra("history_arrlist", history_arrlist);
                startActivityForResult(i, 200);
            }
        });
        Bookmark_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent i= new Intent(MainActivity.this, BookmarkActivity.class);
                i.putExtra("bookmark_arrlist", bookmark_arrlist);
                startActivityForResult(i, 300);
                bookmark_arrlist.clear();
            }
        });
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        int i;
        if(resultCode == RESULT_OK){
            switch(requestCode) {
                case 100:
                    ArrayList<String> items_s = new ArrayList<String>();
                    items_s = (ArrayList<String>) data.getSerializableExtra("result");
                    int history_len = Integer.parseInt(items_s.get(0));
                    for(i=0;i<history_len;i++){
                        history_arrlist.add(items_s.get(i+1));
                    }
                    int index = i+1;
                    int bookmark_len = Integer.parseInt(items_s.get(index++));
                    for(i=index;i<items_s.size();i++){
                        ListViewItem temp = new ListViewItem("","","");
                        temp.setType(items_s.get(i++));
                        temp.setKeyword(items_s.get(i++));
                        temp.setContent(items_s.get(i));
                        bookmark_arrlist.add(temp);
                    }
                    break;
                case 200:
                    ArrayList<String> items_h = new ArrayList<String>();
                    items_h = (ArrayList<String>) data.getSerializableExtra("result");
                    history_arrlist.clear();
                    for(i=0;i<items_h.size();i++){
                        history_arrlist.add(items_h.get(i));
                    }
                    break;
                case 300:
                    ArrayList<ListViewItem> items_b = new ArrayList<ListViewItem>();
                    items_b = (ArrayList<ListViewItem>) data.getSerializableExtra("result");
                    bookmark_arrlist.clear();
                    for(i=0;i<items_b.size();i++){
                        bookmark_arrlist.add(items_b.get(i));
                    }
                    break;
            }
        }
    }
}
