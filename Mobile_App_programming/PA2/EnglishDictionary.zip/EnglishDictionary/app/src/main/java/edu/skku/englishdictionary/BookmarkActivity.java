package edu.skku.englishdictionary;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Iterator;

public class BookmarkActivity extends AppCompatActivity {
    ListViewAdapter adapter = new ListViewAdapter();
    Button back_btn;

    //private ListViewItem[] result = {new ListViewItem()};
    private ArrayList<ListViewItem> result = new ArrayList<ListViewItem>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bookmark_view);

        final Intent intentResult = new Intent(this.getIntent());
        ArrayList<ListViewItem> arrayList;
        arrayList = (ArrayList<ListViewItem>) intentResult.getSerializableExtra("bookmark_arrlist");

        final ListViewItem[] bookmark = {new ListViewItem()};
        final ArrayList<String> sendData = new ArrayList<String>();


        int len = arrayList.size();
        for(int i=0;i<len;i++){
            ListViewItem temp;
            temp = arrayList.get(i);
            adapter.addItem(temp.getType(), temp.getKeyword(), temp.getContent());
        }
        adapter.notifyDataSetChanged();

        ListView listview = (ListView) findViewById(R.id.listview);
        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                final Intent i=new Intent(BookmarkActivity.this,BookmarkSubActivity.class);
                sendData.clear();
                sendData.add(String.valueOf(position));
                bookmark[0] = (ListViewItem) adapter.getItem(position);
                sendData.add(bookmark[0].getType());
                sendData.add(bookmark[0].getKeyword());
                sendData.add(bookmark[0].getContent());
                i.putExtra("data", sendData);
                startActivityForResult(i,100);
            }
        });

        back_btn = (Button)findViewById(R.id.back);
        back_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                int len = adapter.getCount();
                for(int i=0;i<len;i++){
                    result.add((ListViewItem)adapter.getItem(i));
                }
                intentResult.putExtra("result", result);
                setResult(RESULT_OK, intentResult);
                finish();
            }
        });
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList = (ArrayList<String>) data.getSerializableExtra("result");

        if(resultCode == RESULT_OK){
            switch(requestCode){
                case 100:
                    adapter.removeItem(Integer.parseInt(arrayList.get(0)));
                    adapter.notifyDataSetChanged();
                    break;
            }
        }else if(resultCode == RESULT_CANCELED){
            switch(requestCode){
                case 100:
                    break;
            }
        }
    }
}
