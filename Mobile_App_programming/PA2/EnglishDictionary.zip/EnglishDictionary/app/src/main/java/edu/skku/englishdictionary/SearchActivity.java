package edu.skku.englishdictionary;

import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.opencsv.CSVReader;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.Buffer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;

public class SearchActivity extends AppCompatActivity {
    ListViewAdapter adapter = new ListViewAdapter();
    EditText keyword_search;
    String keyword;
    Button search_btn;
    Button back_btn;

    private ArrayList<String> history_arrlist = new ArrayList<String>();
    private ArrayList<ListViewItem> bookmark_list = new ArrayList<ListViewItem>();
    private ArrayList<String> result = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.search_view);

        final Intent i = new Intent(this.getIntent());

        final ListViewItem[] search = {new ListViewItem()};
        final ArrayList<String> sendData = new ArrayList<String>();

        ListView listview = (ListView) findViewById(R.id.listview);
        listview.setAdapter(adapter);
        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                Intent i_sub = new Intent(SearchActivity.this, SearchSubActivity.class);
                sendData.clear();
                sendData.add(String.valueOf(position));
                search[0] = (ListViewItem) adapter.getItem(position);
                sendData.add(search[0].getType());
                sendData.add(search[0].getKeyword());
                sendData.add(search[0].getContent());
                i_sub.putExtra("data", sendData);
                startActivityForResult(i_sub, 100);
            }
        });

        keyword_search = (EditText)findViewById(R.id.keyword_edit);

        search_btn = (Button)findViewById(R.id.search_btn);
        search_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                keyword = keyword_search.getText().toString();
                history_arrlist.add(keyword);
                try {
                    if(isExternalStorageReadable()) {
                        ArrayList<ListViewItem> item = readCSV(keyword);
                        adapter.clear();
                        for(int i=0;i<item.size();i++){
                            adapter.addItem(item.get(i).getType(),item.get(i).getKeyword(), item.get(i).getContent());
                            adapter.notifyDataSetChanged();
                        }
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        back_btn = (Button)findViewById(R.id.back);
        back_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                int history_len = history_arrlist.size();
                result.add(String.valueOf(history_len));
                for(int i=0;i<history_len;i++){
                    result.add(history_arrlist.get(i));
                }
                int bookmark_len = bookmark_list.size();
                result.add(String.valueOf(bookmark_len));
                for(int i=0;i<bookmark_len;i++){
                    result.add(bookmark_list.get(i).getType());
                    result.add(bookmark_list.get(i).getKeyword());
                    result.add(bookmark_list.get(i).getContent());
                }
                i.putExtra("result", result);
                setResult(RESULT_OK, i);
                finish();
            }
        });

    }
    public ArrayList<ListViewItem> readCSV(String keyword) throws IOException {
        char csvName = (Character.toLowerCase(keyword.charAt(0)));

        File fileDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File fileToGet = new File(fileDirectory,csvName+".csv");
        BufferedReader br = new BufferedReader(new FileReader(fileToGet));
        String line;
        String[] tokens = null;
        String dict_key="";
        ArrayList<ListViewItem> result = new ArrayList<>();
        int index = 0;
        while ((line = br.readLine()) !=null) {
            tokens = line.split(" ");
            dict_key = tokens[0].replaceAll("\"", "");
            if (dict_key.toLowerCase().startsWith(keyword.toLowerCase())){
                ListViewItem temp = null;

                String[] type_token_1 = line.split("\\(");
                String type = type_token_1[1].split("\\)")[0];

                String[] content_token = line.split("\\)");
                String content = "";
                for (int i=1;i<content_token.length;i++){
                    content += content_token[i];
                }
                temp = new ListViewItem(type, dict_key, content);
                result.add(temp);
            }
            if(index == 5){
                break;
            }
        }
        return result;
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList = (ArrayList<String>) data.getSerializableExtra("result");

        if(resultCode == RESULT_OK){
            switch(requestCode){
                case 100:
                    Log.d("arrlist", arrayList.get(0));
                    //bookmark_list[index++] = (ListViewItem) adapter.getItem(Integer.parseInt(arrayList.get(0)));
                    bookmark_list.add((ListViewItem) adapter.getItem(Integer.parseInt(arrayList.get(0))));
                    break;
            }
        }else if(resultCode == RESULT_CANCELED){
            switch(requestCode){
                case 100:
                    break;
            }
        }
    }
    public boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();
        if (Environment.MEDIA_MOUNTED.equals(state) || Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            return true;
        }
        return false;
    }
}
