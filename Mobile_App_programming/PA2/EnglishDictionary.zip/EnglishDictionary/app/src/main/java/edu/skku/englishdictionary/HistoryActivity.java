package edu.skku.englishdictionary;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class HistoryActivity extends AppCompatActivity {
    Button back_btn;
    ArrayList<String> history_arrlist;

    ArrayAdapter<String> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.history_view);

        final Intent intentResult = new Intent(this.getIntent());
        history_arrlist = (ArrayList<String>) intentResult.getSerializableExtra("history_arrlist");


        ListView listview = (ListView) findViewById(R.id.listview);
        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, history_arrlist);
        listview.setAdapter(adapter);

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                final Intent i=new Intent(HistoryActivity.this,HistorySubActivity.class);
                String selected_item = (String)adapterView.getItemAtPosition(position);
                ArrayList<String> data = new ArrayList<>();
                data.add(String.valueOf(position));
                data.add(selected_item);
                i.putExtra("data", data);
                startActivityForResult(i,100);
            }
        });

        back_btn = (Button)findViewById(R.id.back);
        back_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                intentResult.putExtra("result", history_arrlist);
                setResult(RESULT_OK, intentResult);
                finish();
            }
        });
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(resultCode == RESULT_OK){
            switch(requestCode){
                case 100:
                    int position = (Integer) data.getSerializableExtra("result");
                    history_arrlist.remove(position);
                    adapter.notifyDataSetChanged();
                    break;
            }
        }else if(resultCode == RESULT_CANCELED){
            switch(requestCode){
                case 100:
                    break;
            }
        }
    }
}
